package com.vti.TestingSystem6;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TestingSystem6Application {

	public static void main(String[] args) {
		SpringApplication.run(TestingSystem6Application.class, args);
	}

}
